# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['manage', 'manage.steps']

package_data = \
{'': ['*'], 'manage': ['examples/*']}

install_requires = \
['pydantic>=1.10.4,<2.0.0',
 'python-dotenv>=0.21.1,<0.22.0',
 'pyyaml>=6.0,<7.0',
 'requests>=2.28.2,<3.0.0',
 'rich>=13.2.0,<14.0.0',
 'toml>=0.10.2,<0.11.0']

entry_points = \
{'console_scripts': ['manage = manage.cli:main']}

setup_kwargs = {
    'name': 'manage',
    'version': '0.0.11',
    'description': "'Manage' environment for poetry-based projects (at least mine)",
    'long_description': '\n* Manage\n  Inspired immensely by [[https://github.com/tfeldmann/organize/blob/main/manage.py][Thomas Feldman\'s manage.py]] script in his [[https://github.com/tfeldmann/organize][Organize]] project, this package automates several common operations for poetry & org-based package management, particularly those that I don\'t perform regularly and/or require multiple steps to perform (and thus, tend to forget how to do them!)\n** Approach\n   The exact steps necessary to complete a /recipe/ are specified in a local ~manage.yaml~ file that is specific to your project (think of it as a set of recipes, one of which you desire to prepare where one recipe may use another).\n** Installation\n   This isn\'t packaged for PyPI. Here\'s how I would approach using this if your interested:\n   - confirm python version availability, I\'m on 3.10.9 for now (and use ~pyenv~ to manage all my versions)\n   - setup a .venv using your virtual-env manager of choice is (I use ~python -m venv .venv~)\n   - clone the repo\n   - ~poetry install~ to install requisite dependencies into your venv.\n   - set .envrc to point top-level directory (i.e. README and pyproject.toml) (thus, I use ~direnv~)\n   - ~python manage check~\n\n   You\'ll note a manage.toml file in the top-level directory so yes, I do eat my own dog-food.\n\n** Assumptions\n*** Tools\n    - [[https://python-poetry.org][Poetry]] is used manage our package dependencies *and* build environment.\n    - We assume that execution of this script is from the TOP level of a project, i.e. at the same level as pyproject.toml.\n    - The version string in pyproject.toml is the SINGLE and CANONICAL version string in our project/package.\n*** Versioning\n    - We use semantic versioning with ~poetry version~ to update/manage our version number.\n*** README Management\n    - We manage our README in an Org format (see [[https://orgmode.org/][Emacs Org Mode]] for details).\n    - We assume ~README.org~ is kept in the top-level directory.\n*** CHANGELOG Management\n    - We do *not* use a stand-alone ~CHANGELOG.md~ file.\n    - We use a specific section in ~README.org~ called /Release History/.\n    - We keep a list of completed but unreleased items in the /Release History/ under an "Unreleased" header.\n*** Configuration\n    - We need *two* --group dev packages over and above our default environment to support this script tomli and requests.\n    - We assume the following entries are available in our environment (either set in shell or through .env):\n     |--------------------------------+-------------------------------------------+--------------------------------------------------------------------------|\n     | GITHUB_USER                    | Github user id                            | JohnJacobJingleheimerSchmidt                                             |\n     | GITHUB_API_TOKEN               | Github personal API token                 | ghp_1234567890ABCDEFG1234567890                                          |\n     | GITHUB_API_RELEASES            | URL to Github release API                 | https://api.github.com/repos/<user>/<project>/releases                   |\n     | GITHUB_PROJECT_RELEASE_HISTORY | URL to release history (for release body) | https://github.com/<user>/<project/blob/trunk/README.org#release-history |\n     |--------------------------------+-------------------------------------------+--------------------------------------------------------------------------|\n** GTD\n   - Would be nice on the "check" request to show statistics after the success() flags (and also on -v or -vv?)\n   - Add a command-line parameter to take a specific poetry version "bump", ie /major/ and /minor/ over and above our current /patch/.\n   - Add a command-line parameter for verbosity (-v, -vv?)\n     - -v:\n       - print absolute paths associated with readme and pyproject.\n       - print package name and version found, how many recipes encountered etc.\n     - -vv:\n       - add explicit output of command executed (sorta like echo_stdout parameter does)\n   - Add step tests:\n     - 90% clean.py\n     -  0% build.py\n     -  0% git_commit_version_files.py\n     -  0% git_create_release.py\n     -  0% git_create_tag.py\n     -  0% git_push_to_github.py\n     -  0% poetry_bump_version_patch.py\n     -  0% publish_to_pypi.py\n     -  0% run_pre_commit.py\n     -  0% update_readme.py\n** Release History\n*** Unreleased\n*** v0.0.11 - 2023-01-29\n    - ADDED: A \'quiet-mode\' step configuration option to remove all extraneous non-failure associated terminal output.\n    - ADDED: A command-line parameter to point to a specific manage recipe file (instead of default manage.toml)\n    - CHANGED: Back to YAML instead of TOML for recipe files (TOML nice for serialisation but too verbose for our use case).\n    - CHANGED: Default value for \'confirm\' step option to True (as most of my steps are using True).\n    - CHANGED: To pydantic for stronger typing of Recipes and their associated steps.\n    - CHANGED: Sample recipe toml files to match pydantic-based data models (in particular, recipes are a dict!).\n*** v0.0.10 - 2023-01-26\n    - ADDED: A "check" recipe/option to simply run the setup & validation steps only.\n    - ADDED: A validation that the version in ~pyproject.toml~ is consistent with the last release in the Release History of ~README.org~.\n    - CHANGED: Terminology from ~target~ to ~recipe~ and manage.toml to consisting of /recipes/.\n    - CHANGED: Steps to make them more "granular" and loaded from ~steps~ module.\n    - CHANGED: Over to TOML (tomli) instead of YAML for recipe files.\n*** v0.0.9 - 2023-01-25\n    - CHANGED: To catch exception when manage.yaml can\'t be opened.\n*** v0.0.8 - 2023-01-25\n    - ADDED: Missing /bin/manage script for execution after pip/poetry install.\n*** v0.0.7 - 2023-01-25\n    - ADDED: Assumptions and example configurations to README.org.\n*** v0.0.6 - 2023-01-25\n*** v0.0.5 - 2023-01-25\n*** v0.0.4 - 2023-01-25\n*** v0.0.3 - 2023-01-25\n*** v0.0.2 - 2023-01-25\n    - Initial packaging.\n',
    'author': 'Peter Borocz',
    'author_email': 'peter.borocz+manage@google.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
