from manage.cli import main

main()
