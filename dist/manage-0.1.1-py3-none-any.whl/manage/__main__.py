"""Driver to allow the module to be called directly."""
from manage.cli import main

main()
