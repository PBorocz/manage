# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['manage']

package_data = \
{'': ['*']}

install_requires = \
['python-dotenv>=0.21.1,<0.22.0',
 'pyyaml>=6.0,<7.0',
 'requests>=2.28.2,<3.0.0',
 'rich>=13.2.0,<14.0.0',
 'tomli>=2.0.1,<3.0.0']

entry_points = \
{'console_scripts': ['manage = manage.manage:main']}

setup_kwargs = {
    'name': 'manage',
    'version': '0.0.8',
    'description': "'Manage' environment for poetry-based projects (at least mine)",
    'long_description': '* Manage\n  Inspired immensely by [[https://github.com/tfeldmann/organize/blob/main/manage.py][Thomas Feldman\'s manage.py]] script in his [[https://github.com/tfeldmann/organize][Organize]] project, this package automates several common operations for poetry & org-based package management, particularly those that I don\'t perform regularly and/or require multiple steps to perform (and thus, tend to forget how to do them!)\n** Approach\n   - The exact steps necessary to achieve a /target/ are specified in a local ~manage.yaml~ file that is specific to your project.\n   - Plugins will be possible by adding operations to the ~manage/commands~ directory (they\'ll be picked up automatically).\n** Assumptions\n*** Tools\n    - [[https://python-poetry.org][Poetry]] is used manage our package dependencies *and* build environment.\n    - We assume that execution of this script is from the TOP level of a project, i.e. at the same level as pyproject.toml.\n    - The version string in pyproject.toml is the SINGLE and CANONICAL version string in our project/package.\n*** Versioning\n    - We use semantic versioning with ~poetry version~ to update/manage our version number.\n*** README Management\n    - We manage our README in an Org format (see [[https://orgmode.org/][Emacs Org Mode]] for details).\n    - We assume ~README.org~ is kept in the top-level directory.\n*** CHANGELOG Management\n    - We do *not* use a stand-alone ~CHANGELOG.md~ file.\n    - We use a specific section in ~README.org~ called /Release History/.\n    - We keep at list of completed by unreleased items in the /Release History/ under an "Unreleased" header.\n*** Configuration\n    - We need *two* --group dev packages over and above our default environment to support this script tomli and requests.\n    - We assume the following entries are available in our environment (either set in shell or through .env):\n     |--------------------------------+-------------------------------------------+--------------------------------------------------------------------------|\n     | GITHUB_USER                    | Github user id                            | JohnJacobJingleheimerSchmidt                                             |\n     | GITHUB_API_TOKEN               | Github personal API token                 | ghp_1234567890ABCDEFG1234567890                                          |\n     | GITHUB_API_RELEASES            | URL to Github release API                 | https://api.github.com/repos/<user>/<project>/releases                   |\n     | GITHUB_PROJECT_RELEASE_HISTORY | URL to release history (for release body) | https://github.com/<user>/<project/blob/trunk/README.org#release-history |\n     |--------------------------------+-------------------------------------------+--------------------------------------------------------------------------|\n** GTD\n   - Add ability to update version by /major/ and /minor/ levels over and above our current /patch/.\n   - Break commands out into ~commands~ sub-module (with dynamic imports obviously)\n   - Convert configuration over to pydantic for validation and documentation (and may toml instead of yaml since we already need tomli for pyproject?)\n** Release History\n*** Unreleased\n*** v0.0.8 - 2023-01-25\n    - CHANGED: Catch exception when manage.yaml can\'t be opened.\n*** v0.0.8 - 2023-01-25\n    - ADDED: Missing /bin/manage script for execution after pip/poetry install.\n*** v0.0.7 - 2023-01-25\n    - ADDED: Assumptions and example configurations to README.org.\n*** v0.0.6 - 2023-01-25\n*** v0.0.5 - 2023-01-25\n*** v0.0.4 - 2023-01-25\n*** v0.0.3 - 2023-01-25\n*** v0.0.2 - 2023-01-25\n    - Initial packaging.\n',
    'author': 'Peter Borocz',
    'author_email': 'peter.borocz+manage@google.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
